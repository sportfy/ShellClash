import{Y as a}from"./vendor-a2162885.js";import{a6 as m}from"./index-c0aef007.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
