import{Y as a}from"./vendor-11b87e0a.js";import{a8 as m}from"./index-cb8474e5.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
